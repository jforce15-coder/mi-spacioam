# Spacio AM — Backend de escritura (Apps Script)

Esto permite que el **Dashboard de Propietarios** escriba directo en tu Google Sheet:
editar SETUP, agregar propiedades, cambiar correos/contraseñas y grabar **Ingreso Neto 2 (Depósito)**.

Solo se instala **una vez**.

---

## 1. Pega el script en tu hoja

1. Abre tu Google Sheet → menú **Extensiones → Apps Script**.
2. Crea un archivo nuevo: ícono **+** junto a "Archivos" → **Secuencia de comandos** → nómbralo `Escrituradesdeapp`.
3. Pega **todo** el contenido de `Escrituradesdeapp.gs`.
4. Edita dos líneas arriba del archivo:
   - `SA_SHEET_ID` → el ID de tu hoja (en la URL, entre `/d/` y `/edit`).
   - `SA_TOKEN` → una contraseña larga y secreta. **Guárdala** (la necesitas en el paso 3).
5. Guarda (💾).

> ⚠️ **Solo puede existir un `doPost` por proyecto de Apps Script.** Si tu script actual
> **ya tiene** una función `doPost`, NO podrás tener dos. En ese caso, crea un
> **proyecto separado**: ve a [script.google.com](https://script.google.com) → **Nuevo proyecto**,
> pega ahí `Escrituradesdeapp.gs` (ya usa `openById`, así que funciona sin estar dentro de la hoja).

## 2. Publica como aplicación web

1. Botón azul **Implementar → Nueva implementación**.
2. Tipo (engranaje) → **Aplicación web**.
3. Configura:
   - **Descripción:** `Spacio AM write API`
   - **Ejecutar como:** *Yo* (tu cuenta).
   - **Quién tiene acceso:** *Cualquier usuario* ✅ (necesario para que el dashboard pueda llamarla).
4. **Implementar** → autoriza los permisos (te pedirá permiso para editar tu hoja; acepta).
5. Copia la **URL de la aplicación web** (termina en `/exec`).

> Prueba rápida: abre esa URL en el navegador. Debe responder `{"ok":true,"service":"Spacio AM write API",...}`.

## 3. Conéctala en el Dashboard

1. Entra al dashboard como **administrador** (`spacioam@gmail.com`).
2. Ve a la pestaña **Setup → Conexión de escritura**.
3. Pega la **URL** (`…/exec`) y el **TOKEN** (el mismo del paso 1).
4. Pulsa **Probar conexión**. Si dice *Conectado*, ya está. ✅

A partir de ahí, todo lo que se guarde en el dashboard se escribe también en la hoja:
- **Setup:** editar fila / agregar propiedad.
- **Mi cuenta:** cambiar correo, contraseña, correo secundario.
- **Depósitos:** botón **Sincronizar depósitos** (graba `Ingreso Neto 2` para las propiedades con retención).

---

## Notas

- Si cambias el `TOKEN` en el script, vuelve a actualizarlo en el dashboard.
- Cada vez que **modifiques el código** del Apps Script, debes **Implementar → Administrar implementaciones → editar (lápiz) → Nueva versión** para que los cambios tomen efecto (la URL se mantiene).
- La hoja debe seguir **publicada en la web** (CSV) para la *lectura*; el Apps Script es solo para la *escritura*. Son dos cosas independientes.
- Seguridad: el token es una barrera básica. Para algo más estricto se puede restringir por dominio o usar una cuenta de servicio; avísame si lo necesitas.
