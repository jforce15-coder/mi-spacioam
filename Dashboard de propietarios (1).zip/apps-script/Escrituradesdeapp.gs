// ============================================================
// Spacio AM — Escritura desde la app (Apps Script) · Escrituradesdeapp.gs
// Permite que el Dashboard escriba en la hoja: SETUP, propiedades,
// credenciales y "Ingreso Neto 2" (Depósito) en Resumenconsolidado.
// Solo puede existir UN doPost por proyecto.
// ============================================================

// 1) ID de TU hoja (en la URL, entre /d/ y /edit).
var SA_SHEET_ID = "1l9wLH8880NlN9ac2jvne2U6cqej6gycqAD77Z25cLF4";

// 2) Cambia este token por una contraseña larga y secreta.
//    El MISMO valor va en el Dashboard (Setup -> Conexion de escritura).
var SA_TOKEN = "CAMBIA-ESTE-TOKEN-secreto-2026";

var SA_TAB_SETUP   = "SETUP";
var SA_TAB_RESUMEN = "Resumenconsolidado";

// ------------------------------------------------------------
// Punto de entrada (POST desde el dashboard)
// ------------------------------------------------------------
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents || "{}");
    if (body.token !== SA_TOKEN) return sa_json({ ok: false, error: "unauthorized" });

    var ss = SpreadsheetApp.openById(SA_SHEET_ID);
    var lock = LockService.getScriptLock();
    lock.waitLock(20000);
    var out;
    try {
      switch (body.action) {
        case "saveProfile":   out = sa_saveProfile(ss, body);  break;
        case "saveSetupRow":  out = sa_saveSetupRow(ss, body); break;
        case "addProperty":   out = sa_addProperty(ss, body);  break;
        case "writeDeposito": out = sa_writeDeposito(ss, body);break;
        case "fetchImage":    out = sa_fetchImage(body);       break;
        case "ping":          out = { ok: true, pong: true, sheet: ss.getName() }; break;
        default:              out = { ok: false, error: "unknown action: " + body.action };
      }
    } finally { lock.releaseLock(); }
    return sa_json(out);
  } catch (err) {
    return sa_json({ ok: false, error: String(err) });
  }
}

function doGet() {
  return sa_json({ ok: true, service: "Spacio AM write API", time: new Date().toISOString() });
}

// Ejecuta esta funcion UNA VEZ desde el editor para autorizar el permiso
// de salida a internet (UrlFetchApp). Necesario para traer la foto del anuncio.
function sa_authorizeExternal() {
  var r = UrlFetchApp.fetch("https://example.com", { muteHttpExceptions: true });
  Logger.log("Autorizado. Codigo: " + r.getResponseCode());
  return r.getResponseCode();
}

// ------------------------------------------------------------
// Helpers
// ------------------------------------------------------------
function sa_json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
function sa_headerMap(sheet) {
  var h = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var map = {};
  for (var i = 0; i < h.length; i++) map[String(h[i]).trim()] = i;
  return map;
}
function sa_setIf(sheet, rowIdx0, map, colName, value) {
  if (value === undefined || value === null) return;
  if (map[colName] == null) return;
  sheet.getRange(rowIdx0 + 1, map[colName] + 1).setValue(value);
}
function sa_normKey() {
  var parts = [];
  for (var i = 0; i < arguments.length; i++) parts.push(String(arguments[i] == null ? "" : arguments[i]));
  return parts.join("||").toLowerCase().replace(/\s+/g, "").replace(/[–—]/g, "-");
}

// 1) Editar una fila de SETUP (por property_id)
function sa_saveSetupRow(ss, body) {
  var sh = ss.getSheetByName(SA_TAB_SETUP);
  var map = sa_headerMap(sh);
  var data = sh.getDataRange().getValues();
  var pidCol = map["property_id"];
  var row = body.row || {};
  for (var r = 1; r < data.length; r++) {
    if (String(data[r][pidCol]).trim() === String(row.property_id).trim()) {
      sa_setIf(sh, r, map, "property_name", row.property_name);
      sa_setIf(sh, r, map, "Usuario ID",   row.usuario);
      sa_setIf(sh, r, map, "User email",   row.email);
      sa_setIf(sh, r, map, "SPACIOAMFEE",  row.fee);
      sa_setIf(sh, r, map, "iva",          row.iva);
      sa_setIf(sh, r, map, "RETENCION",    row.retencion);
      sa_setIf(sh, r, map, "OTRO INGRESO", row.otroIngreso);
      sa_setIf(sh, r, map, "Listing link", row.listing);
      return { ok: true, updated: row.property_id };
    }
  }
  return { ok: false, error: "property_id no encontrado: " + row.property_id };
}

// 2) Agregar una propiedad nueva (fila al final de SETUP)
function sa_addProperty(ss, body) {
  var sh = ss.getSheetByName(SA_TAB_SETUP);
  var map = sa_headerMap(sh);
  var row = body.row || {};
  var arr = [];
  for (var i = 0; i < sh.getLastColumn(); i++) arr.push("");
  function put(col, val) { if (map[col] != null && val != null) arr[map[col]] = val; }
  put("property_id",  row.property_id || ("P" + Date.now()));
  put("property_name",row.property_name);
  put("Usuario ID",   row.usuario);
  put("User email",   row.email);
  put("Password",     row.password);
  put("SPACIOAMFEE",  row.fee);
  put("iva",          row.iva);
  put("RETENCION",    row.retencion);
  put("OTRO INGRESO", row.otroIngreso);
  put("Listing link", row.listing);
  put("secondary user email", row.secondary);
  sh.appendRow(arr);
  return { ok: true, added: arr[map["property_id"]] };
}

// 3) Cambiar credenciales (correo / contraseña / correo secundario)
function sa_saveProfile(ss, body) {
  var sh = ss.getSheetByName(SA_TAB_SETUP);
  var map = sa_headerMap(sh);
  var data = sh.getDataRange().getValues();
  var codes = body.codes || (body.code ? [body.code] : []);
  var n = 0;
  for (var r = 1; r < data.length; r++) {
    var uid = String(data[r][map["Usuario ID"]]).trim();
    if (codes.indexOf(uid) >= 0) {
      if (body.email != null && body.email !== "")       sh.getRange(r + 1, map["User email"] + 1).setValue(body.email);
      if (body.password != null && body.password !== "") sh.getRange(r + 1, map["Password"] + 1).setValue(body.password);
      if (body.secondary != null)                        sh.getRange(r + 1, map["secondary user email"] + 1).setValue(body.secondary);
      n++;
    }
  }
  return { ok: true, rowsUpdated: n };
}

// 4) Grabar "Ingreso Neto 2" (Depósito) en Resumenconsolidado
function sa_writeDeposito(ss, body) {
  var sh = ss.getSheetByName(SA_TAB_RESUMEN);
  var map = sa_headerMap(sh);
  var col = map["Ingreso Neto 2"];
  if (col == null) return { ok: false, error: "Falta la columna 'Ingreso Neto 2'" };
  var data = sh.getDataRange().getValues();
  var items = body.items || [];
  var idx = {};
  for (var i = 0; i < items.length; i++) {
    idx[sa_normKey(items[i].usuario, items[i].property_name, items[i].mes)] = items[i].value;
  }
  var n = 0;
  for (var r = 1; r < data.length; r++) {
    var k = sa_normKey(data[r][map["Usuario ID"]], data[r][map["Property_name"]], data[r][map["Mes"]]);
    if (idx[k] != null) { sh.getRange(r + 1, col + 1).setValue(idx[k]); n++; }
  }
  return { ok: true, rowsUpdated: n };
}

// 5) Traer la foto principal (og:image) de un anuncio
function sa_fetchImage(body) {
  var url = body.url;
  if (!url) return { ok: false, error: "no url" };
  try {
    var html = UrlFetchApp.fetch(url, { muteHttpExceptions: true, followRedirects: true, headers: { "User-Agent": "Mozilla/5.0" } }).getContentText();
    var img = sa_meta(html, "og:image") || sa_meta(html, "twitter:image");
    if (!img) { var m = html.match(/<img[^>]+src=["']([^"']+\.(?:jpg|jpeg|png|webp)[^"']*)["']/i); if (m) img = m[1]; }
    if (img && img.indexOf("//") === 0) img = "https:" + img;
    return { ok: true, image: img || "" };
  } catch (e) { return { ok: false, error: String(e) }; }
}
function sa_meta(html, prop) {
  var re = new RegExp('<meta[^>]+(?:property|name)=["\']' + prop + '["\'][^>]*content=["\']([^"\']+)["\']', "i");
  var m = html.match(re);
  if (m) return m[1];
  re = new RegExp('<meta[^>]+content=["\']([^"\']+)["\'][^>]*(?:property|name)=["\']' + prop + '["\']', "i");
  m = html.match(re);
  return m ? m[1] : null;
}
